from tablero import Tablero


mi_tablero = Tablero("Imola", 0, 11)

print(mi_tablero)

print("_" * 90)
mi_tablero.imprimir()
print("_" * 90)
