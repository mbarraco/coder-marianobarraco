
# python setup.py sdist
from setuptools import setup

setup(
    name="tablero",
    version="0.1",
    description="Tablero para juego lineal",
    author="mbarraco",
    author_email="mbarraco@gmail.com",
    packages=["entrega1", "entrega2"]
)