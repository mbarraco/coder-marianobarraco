from matematica import sumar


mi_suma = sumar(1, 2)
print(mi_suma)


# Forma alternativa
import matematica


mi_suma = matematica.sumar(1, 2)
print(mi_suma)
mi_division = matematica.dividir(1, 2)
print(mi_division)

# Forma alternativa II
from matematica import *


mi_suma = sumar(1, 2)
print(mi_suma)
mi_division = dividir(1, 2)
print(mi_division)