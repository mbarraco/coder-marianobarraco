from setuptools import setup


setup(
    name="paquete_redistribuible",
    version="0.2",
    description="estudiando redistribución de paquetes",
    author="mbarraco",
    author_email="mbarraco@gmail.com",
    packages=["paquete_redistribuible"]
)