from setuptools import setup


setup(
    name="entregas_coder",
    version="0.1",
    description="Entregas de coder 47790",
    author="mbarraco",
    author_email="mbarraco@gmail.com",
    packages=["actividad_1", "actividad_2"]
)