from setuptools import setup, find_packages

setup(
    name='paquete',
    version='0.1',
    packages=find_packages(),
    # packages=["paquete"],  #  forma alternativa
    description='Preentrega 2',
    author='Mariano Barraco',
    author_email='marianobarraco@gmail.com',
    keywords='coder python preentrega2',
)