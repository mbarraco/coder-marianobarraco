from setuptools import setup, find_packages

setup(
    name='paquete',
    version='0.1',
    packages=["paquete"],
    description='Un simple paquete de ejemplo',
    author='Tu Nombre',
    author_email='tu_email@example.com',
    keywords='ejemplo paquete',
)