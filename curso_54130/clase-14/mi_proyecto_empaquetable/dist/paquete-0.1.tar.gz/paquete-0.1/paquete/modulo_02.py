import time


def saludar_n_veces(n: int):

    for i in range(n):
        print(i+1, "Hola!!")
        time.sleep(.5)