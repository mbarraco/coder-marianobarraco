from setuptools import setup


setup(
    name="mi_primer_paquete",
    version="0.1",
    description="Primer paquete redistribuible",
    author="Mariano",
    author_email="marianobarraco@gmail.com",
    packages=["mi_primer_paquete"]
)