from calculadora import suma, MODELO


print(suma(2,3))
print(f"Este resultado fue calculado por el dispositivo: {MODELO}")

