MODELO = "fx82_fraction"

def suma(a, b):
    return a + b